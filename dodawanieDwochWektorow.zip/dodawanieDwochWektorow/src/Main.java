import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
// pytamy o pierwszy wektor
        System.out.print("podaj 1 wektor [a,b]: ");
        String w1 = s.nextLine();

// pytamy o drugi wektor
        System.out.print("podaj 2 wektor [a,b]: ");
        String w2 = s.nextLine();

// szukamy przecinka w pierwszym wektorze
        int przecinek1 = w1.indexOf(',');
// wycinamy pierwszą liczbę z pierwszego wektora
        int x1 = Integer.parseInt(w1.substring(1,przecinek1));
// wycinamy drugą liczbę z pierwszego wektora
        int y1 = Integer.parseInt(w1.substring(przecinek1+1,w1.length()-1));

// to samo dla drugiego wektora
        int przecinek2 = w2.indexOf(',');
        int x2 = Integer.parseInt(w2.substring(1,przecinek2));
        int y2 = Integer.parseInt(w2.substring(przecinek2+1,w2.length()-1));

// dodajemy współrzędne
        int x = x1+x2;
        int y = y1+y2;

// wypisujemy wynik
        System.out.println("wynik to ["+x+","+y+"]");
    }
}
